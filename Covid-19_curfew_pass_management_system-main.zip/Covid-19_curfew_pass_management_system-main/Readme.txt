How to run the Covid-19 Curfew e-Pass Management System Project

1.Clone the Repository

2.Extract the file and copy cpms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5.Create a database with name cpms

6.Import cpms.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/cpms

Admin Credential
Username: lucky
Password: cepms

Pass Id: 884595667
if Any issue Occured Contact :- 8765778665  , Email:- lakhitolani41@gmail.com
