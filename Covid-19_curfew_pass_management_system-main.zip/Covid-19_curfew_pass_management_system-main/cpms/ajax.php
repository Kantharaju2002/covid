<html>

<head>
    <title></title>
</head>

<body>
    <div>
        <img src="symptom.png" alt="symptom" height="400px">
    </div>
</body>

</html>